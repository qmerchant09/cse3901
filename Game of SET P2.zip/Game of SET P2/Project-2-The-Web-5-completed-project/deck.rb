=begin
File created 9/6 by Gavin A
File edited on 9/7 by Gavin A
File edited on 9/12 by Gavin A
Edited 9/16 by Gavin A
Edited 9/21 by Gavin A

The deck class is the representation of the deck of cards in the Game of Set
Upon initialization, every possible card for the game (represented by the Card class) is inserted into the deck
The deck will have cards removed from it until the game ends
=end
require_relative './card.rb'
class Deck  
=begin
    Created 9/5 by Gavin A
    Edited 9/7 by Gavin A: Fixed syntax errors and the deck 
           is now shuffled before returning. Changed array assignments
           to use parallel assignment
    Edited 9/16 by Gavin A: Condensed the each statements to one line
    Generates every possible card and adds it to the deck array, and shuffles the cards
=end
    def initialize
        @cards, numbers, colors, shapes, shadings = [], ["1", "2", "3"], ["purple", "red", "green"], ["diamond", "pill", "tilda"], ["empty", "solid", "striped"]
        numbers.each {|number|  colors.each {|color| shapes.each {|shape| shadings.each {|shading| @cards << Card.new(number, color, shape, shading)}}}}
        @cards.shuffle!
    end

=begin
     Created 9/7 by Gavin A
     Returns the length of the deck
=end
    def length
        @cards.length
    end

=begin
    Created 9/7 by Gavin A
    Edited 9/16 by Gavin A: Makes sure deck has a card before removing
                            Makes use of a ternary operator to reduce to one line

    This method attempts to remove a card from the front of the deck
    Removes and returns the card at the front of the deck if the deck has one
    Returns nil and prints a message to the console if there are no cards to remove
=end
    def remove
        @cards.length > 0 ? @cards.shift : (puts "no more cards to remove")
    end

=begin
    Created 9/7 by Gavin A
    Edited 9/12 by Gavin A: The provious solution only returned false, 
             which is fixed by looping through the array manually
    Edited 9/16 by Gavin A: Replaced for loop with @cards.each

    Receives an instance of the card class as a parameter and determines if the deck has that card
    This method exists solely for testing purposes
=end
    def include? card
        hasCard = false
        @cards.each do |c|
            if(c.equal_to? card) then hasCard = true end
        end
        hasCard
    end
end