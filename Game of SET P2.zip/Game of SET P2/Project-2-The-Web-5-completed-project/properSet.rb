=begin
Created by Selemon 9/8/22
 Edited by Selemon1 9/9
 Edited 9/12 by Gavin A
 Edited by Selemon1 9/13
 Edited 9/14 by Gavin A
 Edited 9/15 by Quantez M
 Edited 9/16 by Gavin A
 Edited 9/16 by selemon1
 Edited 9/19 by Gavin A
 Edited 9/21 by Amyas D
=end
require_relative './card'
require_relative './deck'

=begin
 created by selemon 9/9
 Eidited by Selemon 9/9: Overhaul of previous solution because of a misunderstanding of the requirements
 Editing by selemon 9/9: correcting elseif to elsif, syintax by changing "color = false" for ealse if statment and adding the documentation
 Edited by Gavin A 9/12: Fixing syntax errors for method name and elseif statements. Added line at
                              bottom to return whether the cards make a set
 Edited by Gavin A 9/14: Fixed spacing as a result of removing the defining class
 Edited by Quantez Merchant 9/16/22: Condensed the logic
 Edited by Gavin A 9/16: Got rid of unnecessary assignment statement, removed parentheses
 Edited 9/19 by Gavin A: Condensed logic more
 Edited 9/19 by selemon1: editing doucumtation
 Edited 9/21 by Amyas D: added '?' to method name to show it returns a boolean
 
 This method takes three Card class instances and determines if they make a valid set based on their attributes
=end
def is_set? card1, card2, card3
    b1 = (same_or_dif? card1.color, card2.color, card3.color) && (same_or_dif? card1.number, card2.number, card3.number)
    b2 = (same_or_dif? card1.shape, card2.shape, card3.shape) && (same_or_dif? card1.shading, card2.shading, card3.shading)
    b1 && b2
end

=begin
 Created by Gavin A 9/12
 Edited by Quantez Merchant 9/15/22: Added logic to the method
 Edited by Gavin Adams 9/16: Changed some of the logic to ensure val1 != val3
 Edited by selemon1 9/16: condensing the code 
 Edited 9/16 by Gavin A: made code one line
 Edited 9/19 by Gavin A: Changed name of method
 Edited 9/21 by Amyas D: added '?' to method name to show it returns a boolean

 Returns true if the three values taken as parameters are all different or all the same
=end
def same_or_dif? val1, val2, val3
    (val1 == val2 && val2 == val3)||(val1 != val2 && val2 != val3 && val1 != val3)
end
