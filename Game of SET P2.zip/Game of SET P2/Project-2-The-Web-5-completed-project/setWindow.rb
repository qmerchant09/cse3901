# File created 9/6 by Quantez Merchant 
require'fox16'
require_relative './card'
require_relative './deck'
require_relative './board'
require_relative './properSet'

include Fox
 
# The SetWindow class represents the visual aspect of the game, including the board, cards, and gameplay features.
class SetWindow < FXMainWindow
=begin
    Created 9/6 by Quantez Merchant
    Edited 9/7 by Quantez Merchant: Added functionality 
    Edited 9/11 by Quantez Merchant: Edited functionality 
    Edited 9/13 by Quantez Merchant: Edited functionality 
    Edited 9/14 by Gavin A: Added an array for player scores and the game board
    Edited 9/16 by Quantez Merchant: Added functionality to buttons
    Edited 9/19 by Quantez Merchant: Added functionality to add cards button
    Edited 9/19 by Quantez Merchant: added scoring functionality, an end game button, and a rules menu
    Edited 9/20 by Gavin A: Condensed slot creation in gui with addition of a slotArray
    Edited 9/22 by Quantez Merchant: moved code into methods and added a hintArray 
    Edited 9/21 by Gavin A: Added condition to help menu that specifies that only 15 cards can be on the board
=end
   def initialize app
      
      # Gives the gui window a title   
      super app, "Game of SET"
     
      # Adds a help menu to the top to show basic rules
      menu = FXMenuBar.new self, LAYOUT_SIDE_TOP|LAYOUT_FILL_X
      help = FXMenuPane.new self
      FXMenuCommand.new(help, "How to play SET").connect SEL_COMMAND do
         FXMessageBox.information(self, MBOX_OK, "How to play SET", "Each card has 1 of 3 colors (green, purple, red), 1 of 3 numbers (1-shape, 2-shapes, 3-shapes), 1 of 3 shadings (empty, solid, striped), 1 of 3 symbols (pills, tildas, diamonds).
          The object of the game is to identify a SET of 3 cards from 12 cards placed face-up on the table. A SET consists of 3 cards in which each of the cards' features, looked at one-by-one, are the same on each card, or, are different on each card. 
          All of the features must separately satisfy this rule. In other words: shape must be either the same on all 3 cards, or different on each of the 3 cards; color must be either the same on all 3 cards, or different on each of the 3, etc. 
          If no sets can be identified, 3 more cards can be added from the deck. The board may only have 15 cards at a time. The game lasts until the end game button is hit, or the deck is emptied. The winner is the player with the most amount of points.")
      end
      FXMenuTitle.new menu, "Help", nil, help, LAYOUT_RIGHT
      
      # Initializes a new deck, board, setArray, imgArray, slotArray, playerscores array, hintArray, and card placeholder
      @deck = Deck.new 
      @board = Board.new
      @board.generate_cards @deck, 12
      @setArray = []
      @imgArray = []
      @slotArray = []
      @playerScores = [0, 0]
      @hintArray = []
      @card = Card.new nil,nil,nil,nil
      
      # Initializes different sections of the gui 
      @matrix = FXMatrix.new self, 3, MATRIX_BY_ROWS
      bottom = FXHorizontalFrame.new self,LAYOUT_SIDE_BOTTOM|FRAME_NONE|LAYOUT_FILL_X 
      top = FXHorizontalFrame.new self, LAYOUT_SIDE_TOP|FRAME_NONE|LAYOUT_FILL_X|LAYOUT_FILL_Y
      
      # Generates buttons for the cards in the board instance
      @index = 0
      generateSlots
      
      # Creates buttons to check the set, add more cards, and generate a hint
      checkButton = FXButton.new top, "Check SET", :opts => BUTTON_NORMAL, :padding => 21
      checkSet checkButton
      addCardsButton = FXButton.new top, "Add More Cards", :opts => BUTTON_NORMAL, :padding => 21
      addThree addCardsButton
      hintButton = FXButton.new top, "Hint", :opts => BUTTON_NORMAL, :padding => 21
      hintButton.connect SEL_COMMAND do
         if @board.find_set != nil
            arr = @board.find_set
            @hintArray << "?"
            @hintArray << @board.get_card_index(arr[1])
            @hintArray << "?"
            FXMessageBox.information self,MBOX_OK,"Hint","There is at least 1 SET on the board Hint:#{@hintArray}."
         elsif @board.length > 12 && @board.find_set == nil
            FXMessageBox.information self,MBOX_OK,"Hint","There are currently no SETS on the board."
         elsif @deck.length == 0 && @board.find_set == nil
            FXMessageBox.information self,MBOX_OK,"Hint","There are currently no SETS on the board."
         else
            FXMessageBox.information self,MBOX_OK,"Hint","There are currently no SETS on the board, add more cards."
         end
         @hintArray.clear
      end
      
      # Creates buttons to show and update the players score
      @scoreOneButton = FXButton.new bottom, "Player 1: #{@playerScores[0]}",:opts => BUTTON_NORMAL, :padding => 21
      @scoreTwoButton = FXButton.new bottom, "Player 2: #{@playerScores[1]}",:opts => BUTTON_NORMAL, :padding => 21
      
      # Creates a button to end the game and declare the winner
      FXButton.new(bottom, "End Game", :opts => LAYOUT_RIGHT|BUTTON_NORMAL , :padding => 21).connect SEL_COMMAND do
         endGame
      end
   
   end

   # Created 9/21 by Quantez Merchant
   # Creates the slots that the cards are placed into on the back end
   def generateSlots
      12.times do
         @card = @board.get_card @index
         @imgArray << (getIcon"#{@card.filename}.png")
         @imgArray << (getIcon "#{@card.filename}clicked.png")
         @slotArray << (FXToggleButton.new @matrix,@index.to_s,@index.to_s, @imgArray[@index*2], @imgArray[(@index*2)+1], nil, 0, TOGGLEBUTTON_NORMAL)
         buttonClick @slotArray[@index],@index
         @index += 1
      end
   end

   # Created 9/16 by Quantez Merchant
   # Edited 9/20 by Gavin A: Changed set array to contain card indicies instead of the card
   # Adds or removes the index of the clicked button to the set array
   def buttonClick slot, index
      slot.connect SEL_COMMAND do
         if slot.state && @setArray.length < 3
            @setArray << index
         else
            @setArray.delete index
         end
      end
   end

=begin
    Created 9/16 by Quantez Merchant
    Edited 9/17 by Quantez Merchant: Added strings to get rid of redundant method
    Edited 9/20 by Quantez Merchant: Added scoring functionality and removed dialog box class
    Edited 9/20 by Gavin A: Changed the is_set parameter since setArray now contains indicies
    Edited 9/21 by Quantez Merchant: Added reset method
    Edited 9/22 by Gavin A: Fixed method name for is_set? due to change
    Determines which popup menu to show when the Check Set button is clicked based on if the three cards make a set
=end
   def checkSet button
      button.connect SEL_COMMAND do 
         if @setArray.length < 3
            FXMessageBox.information self,MBOX_OK,"Check SET","3 cards haven't been selected."
         elsif is_set? @board.get_card(@setArray[0]),@board.get_card(@setArray[1]),@board.get_card(@setArray[2])
            choosePlayer
            if @deck.length > 0 
               replaceCards
            else 
               endGame                
            end
         else
            FXMessageBox.information self,MBOX_OK,"Check SET","Not a SET." 
            reset
         end 
          
      end
   end

   # Created 9/20 by Gavin A
   # Creates a popup window to ask the user which player found the set
   def choosePlayer
      value = 0
      until value == 1 do 
         response = FXMessageBox.information self,MBOX_YES_NO,"Check SET","Did player 1 find the SET?"
         if MBOX_CLICKED_YES == response
            @scoreOneButton.text = "Player 1: #{@playerScores[0] += 1}"
            value = 1
         elsif MBOX_CLICKED_NO == response
               response = FXMessageBox.information self,MBOX_YES_NO,"Check SET","Did player 2 find the SET?"
         if MBOX_CLICKED_YES == response
            @scoreTwoButton.text = "Player 2: #{@playerScores[1] += 1}"
           value = 1
            end
         end
      end
   end

   # Created 9/21 by Quantez Merchant
   # Resets the clicked buttons and clears the set array
   def reset
      @slotArray[@setArray[0]].state = false
      @slotArray[@setArray[1]].state = false
      @slotArray[@setArray[2]].state = false  
      @setArray.clear
   end

=begin
    Created 9/20 by Gavin A
    Edited 9/20 by Quantez Merchant: Method now replaces cards
    Edited 9/21 by Quantez Merchant: Added reset method
    Replaces the cards in the found set with new cards and updates the images on the gui accordingly
=end
   def replaceCards
      @board.update_board @deck, @setArray
      @setArray.each do |i|
         @card = @board.get_card i
         newIcon1 = (getIcon "#{@card.filename}.png")
         newIcon2 =  (getIcon "#{@card.filename}clicked.png")
         newIcon1.create
         newIcon2.create
         @imgArray[i*2] = newIcon1
         @imgArray[(i*2)+1] = newIcon2
         @slotArray[i].icon = @imgArray[i*2]
         @slotArray[i].altIcon = @imgArray[(i*2)+1]
         buttonClick @slotArray[i],i
      end
      reset
   end

=begin
    Created 9/19/22 by Quantez Merchant
    Edited 9/20 by Gavin A: Condensed logic using the slot array
    Edited 9/22 by Quantez Merchant: added find_set functionality and a popup messages
    Adds three more cards from the deck into the array and on the screen
=end
   def addThree button
      button.connect SEL_COMMAND do
         if @board.length == 12 && @board.find_set == nil 
            @index = @board.length
            @board.generate_cards @deck, 3
            3.times do 
               @card = @board.get_card @index
               @imgArray << (getIcon "#{@card.filename}.png")
               @imgArray << (getIcon "#{@card.filename}clicked.png")
               @slotArray << (FXToggleButton.new @matrix,@index.to_s,@index.to_s, @imgArray[@index*2], @imgArray[(@index*2)+1], nil, 0, TOGGLEBUTTON_NORMAL)
               @slotArray[@index].create
               @slotArray[@index].recalc
               buttonClick @slotArray[@index],@index
               @index += 1
            end
         elsif @board.length > 12
            FXMessageBox.information self,MBOX_OK,"SET","Maximum number of cards on the board."
         elsif @deck.length == 0
            FXMessageBox.information self,MBOX_OK,"SET","There are no more cards left in the deck."
         else
            FXMessageBox.information self,MBOX_OK,"SET","There is a SET on the board."
         end
      end
   end

   # Created 9/21 by Quantez Merchant
   # Ends the game and declares a winner with a popup
   def endGame
      if @playerScores[0] > @playerScores[1]
         FXMessageBox.information self,MBOX_OK,"WINNER","Player 1 wins!"
         getApp.exit 0
      elsif @playerScores[0] == @playerScores[1]
         FXMessageBox.information self,MBOX_OK,"TIE","Player 1 and Player 2 tied."
         getApp.exit 0
      else
         FXMessageBox.information self,MBOX_OK,"WINNER","Player 2 wins!"
         getApp.exit 0
      end
   end
   
=begin
    Created 9/7 by Quantez Merchant
    Edited 9/8 by Quantez Merchant: Fixed path to the repository path
    Edited 9/17 by Quantez Merchant: Made more terse
    Opens the image folder and grabs the image that matches the given filename
=end
   def getIcon filename
      filename = File.expand_path "../Project-2-The-Web-5/Images/#{filename}", File.dirname(__FILE__)
      File.open filename, "rb" do |file| FXPNGIcon.new getApp, file.read end
   end

   # Created 9/6 by Quantez Merchant
   # Creates the main window
   def create    
      super 
      show PLACEMENT_MAXIMIZED
   end
end

# Created 9/6 by Quantez Merchant
# Initializes the new window, creates it, and then runs it
def setWindow
      FXApp.new do |app| 
         SetWindow.new app
         app.create
         app.run
      end
end