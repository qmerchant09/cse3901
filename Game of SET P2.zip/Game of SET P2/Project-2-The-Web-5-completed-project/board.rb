=begin
File created 9/9 by Amyas D
 File edited 9/12 by Gavin A
File edited 9/16 by Amyas D
 Edited 9/19/ by Gavin A
 Edited 9/21 by Roberto D
 Edited 9/22 by Quantez Merchant
=end
require_relative './card'
require_relative './deck'
require_relative './properSet'

=begin
Created 9/9 by Amyas D
 The board class is the representation of the game board that players interact with directly
=end
class Board 
=begin
    Created 9/9 by Amyas D
     Edited 9/16 by Amyas D: added @length back for testing
     Edited 9/19 by Gavin A: Removed @length and parentheses
    The board is represented by an initially empty array
=end
    def initialize
        @cards = []
    end

=begin
    Created 9/9 by Amyas D
     Edited 9/14 by Gavin A: added the deck as a parameter, changed to be more like ruby and not java
     Edited 9/16 by Amyas D: combined normal and no_match_board into one
     Edited 9/19 by Gavin A: Put the each loop on one line, removed parentheses
     Generates the cards that will be on the board by placing them into the @cards array
=end
    def generate_cards deck, numCards
        if deck.length >= numCards
            numCards.times {@cards << deck.remove}
        end
    end

=begin
     Created 9/19 by Gavin A
     Takes an array of card indicies of length 3 as a parameter
     Takes an array of indicies as a parameter and removes each from the board
     Requires that each entry for the indexArray variable is between 0 and the length of the board
     Ensures that only the intended cards are removed
=end
    def remove_three indexArray
        if @cards.length > 2 then
            indexArray.sort!
            3.times {@cards.slice!(indexArray.pop)}
        end
    end

    
    # Created 9/16 by Quantez Merchant
    # Returns the card at the given index on the board
    def get_card index
        @cards[index]
    end

    # Created 9/22 by Quantez Merchant
    # Returns the index of the given card on the board
    def get_card_index card
        index = @cards.index card
    end

    # Created 9/22 by Quantez Merchant
    # Returns the first set found on the board, or nil if no set exists 
    def find_set
        setCombo = @cards.combination(3).to_a
        set = setCombo.find {|card1,card2,card3| is_set?(card1,card2,card3)}
    end

    # Created 9/12 by Gavin A
    # Returns the length of the board representation
    def length
        @cards.length
    end

=begin
    Created 9/9 by Amyas D
    Edited 9/16 by Amyas D: shortened lines of code for same functionality
     Edited 9/19 by Gavin A: Moved the each block to one line
     This function replaces cards that have been taken off of the board in their respective indices
=end
    def update_board deck, indexArray
        indexArray.each { |index| @cards[index] = deck.remove}
    end
    
=begin
     Created 9/19 by Gavin A
     Edited 9/21 by Roberto D: Added indexes and headers for print columns
     Prints the values for every card instance currently on the board
=end
    def print_board
        i = 0
        puts "\nINDEX\tSHAPE\tCOLOR\tNUMBER\tFILL"
        @cards.each {|card| puts "#{i += 1}\t#{card.shape}\t#{card.color}\t#{card.number}\t#{card.shading}"}
    end
end
