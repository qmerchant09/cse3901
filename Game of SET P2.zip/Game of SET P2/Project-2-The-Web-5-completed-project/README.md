# Project-2-The-Web-5

This game has two modes. The text-based version can be run on the console, but the mouse based version uses FXRuby. This requires the user to download FXRuby (and sometimes XQuartz too) to be able to run the game. Instructions on how to download can be found here. https://rubydoc.info/gems/fxruby/frames. If the user does not want to download FXRuby, line 7 in the main.rb (“require_relative './setWindow.rb'”) can be commented out using the pound symbol. Note, option 1 must be selected if the user chooses not to download FXRuby.

To start the game, please run main.rb by typing “ruby main” in the console

# Sprint #1:
All team members attended the meeting to work on this submission. 
Gavin is responsible for submitting the first sprint to github and carmen. 

Overall project manager: Gavin Adams
Implementation manager: Amyas Dawson
Documentation manager: Roberto De Jesus
Testing manager: Selemon Bushra
Meeting manager: Quantez Merchant


Use Cases
Use case 1: User starts game and wants to select a card they think is a part of a set on the board
Use case 2: The user-identified set is incorrect
Use case 3: User accidentally chooses the wrong card and wants to deselect the card they previously selected
Use case 4: Player sees a set and wants to call it so they can select cards
Use case 5: The user is looking for sets but there are none currently on the board
Use case 6: User wins the game and can choose to start a new game or quit
Use case 7: User creates a correct set and new cards must be added to the board


Functionality and Allocation of Work
Gavin will be creating a structure called Card that holds values for each attribute necessary for functionality in the game. Color, Number, Shape, Shading (maybe others. Could add more for ease of implementation)
Gavin will create another structure/array called deck from which the game board will draw
    May need to hash to show if the card has been added to the board or not
    Will also need to shuffle the deck so cards are not placed in order

Amyas will create an array that contains the cards currently on the game board
    This board will be updated when a set is made, drawing from the deck and making sure no duplicate cards show up
Amyas will create an initially empty array for 3 cards to be added when no sets exist on the board
    Will also require a check for seeing if no sets exist, which will be user initiated

Quantez will create a visual game interface using fxruby (https://rubydoc.info/gems/fxruby/frames) for ease of player use
    Shows the cards currently on the board
    Should allow a player to select and deselect a card by clicking on it

Selemon will create a function for checking if three cards make a proper set
Selemon will implement test cases to ensure the game knows every possible set combination
    If cards do make a set, increase the score for the player that made it

Roberto will make the program require player selection in order to create a set
    Once all cards are used, end the game and determine a winner based on point values of each player
Roberto will make user selection of cards possible by having the user select the index of the card that they want to select or deselect
Roberto will generate every card for the main deck and add 12 into the game board upon startup
If we have time, Roberto will add a timer that activates when a player selection is made, and deactivates once a set is made.
    This timer will deselect the player once it times out so that one player can’t call set and prevent other players from doing so

# Sprint #2:

Gavin created the Card class, the Deck class, main.rb, and setText.rb. Gavin contributed some work to setWindow.rb, the Board class, and properSet.rb. 
Gavin contributed functionality for the Card class involving getting each attribute of a card instance, determining if one card is equal to another, and generating a unique filename for the card instance based on its attributes. 
Gavin ensured each instance of the Deck class begins with all 81 unique card instances and shuffles the deck so the game is not the same every time. Gavin created methods for this class to return the length of the deck, to remove a card from the deck, and to determine if a specific card instance is included in the deck.
Gavin created the gameVersion method, which has the user decide which version of the game they want to use. Gavin also created the main method, which launches the version of the game specified by the user.
Gavin created the setText method, which runs the text-based version of the game of set, but other members filled in most of the logic.
Gavin created the remove_three method in the Board class which removes three cards from the board based on the indices passed as a parameter. Gavin also created the method for returning the length of the board instance. Gavin created the print_board method which prints every card currently on the board.
Gavin created the method same_or_dif? but Quantez wrote the logic for it.
He has tested every method for the card and deck classes. Gavin has created tests for the board class and the same_or_dif? method as well. Any other functionality or tests not mentioned here are documented in the code.

Amyas worked on the Board class, setText, PlayerScore class, properSet methods, and added to cardTests. Amyas’s contributions were documented as comments in each file. 

Roberto created the playerSelection, cardsSelection, and getInput methods. The playerSelection method gets an input of “1” or “2” from the user to specify which user is going to make a selection of cards. The cardsSelection method calls getInput to get an input of 3 indexes of cards that the player is selecting as a set. The getInput method also uses the Thread class to create a 10 second timer for the player to make their cards selection. This input is then returned to the cardsSelection method and is then checked for validity. The input is checked to make sure it is 3 different indexes and that each index is between 1 and the length of the board. These methods are used in the setText method to allow for user interaction for the text-based version of the game. Roberto created the test cases for these three methods. Roberto documented all of his contributions to these methods.

Selemon created the properSet and is_set method, Created the file and the method and re-wrote the whole code before the refactorization. In addition, Selemon corrects syntax errors.
Selemon created properSet_tests which is a test file for properSet. properSet has is_set and sam_or_dif methods. Created  6 test cases for is_set method and edited them, fix errors and rename. And also fix errors for sam_or_dif test cases.
Selemon also created a PlayerScore file PlayerScore with two methods such as player_scores and winner methods. 
Selemon created the player_scores methods with the parameters and logics that increase the score for the player who scored and the messages that display when the condition is fulfilled.  
Selemon also created winner methods which is setting up winning conditions. 
Including the parameters and logics with the messages displayed when the winning condition is satisfied. Selemon also edited and correct the documentation in properSet, PlayerScore and       
properSet_test files. 
The methods and tests that Selemon created and contributed to are documented.

Quantez created the setWindow class, its functionality, and the clicked images for the game. He created methods to generate icons and buttons for each slot of the game window. 
He made methods which cause the window to respond to the user clicking on buttons. Users can select cards by clicking on them, and can check if they are a set by clicking the Check Set button. If the number of cards selected is not three, or the three cards do not make a set, then a dialogue box will appear telling the user they have made incorrect input. 
If the three cards do make a set, a dialogue box appears asking the user if player 1 scored or if player 2 scored (requiring a yes or no answer). Based on which player is selected, that player’s score is incremented. 
The cards that were a part of the set are then replaced with three different cards. 
If there is no set to be made on the board, the user can choose to add three more cards to the board. 
If the user is stumped, the user can choose to get a hint determining whether a set can be found on the board, and if so, what one of the cards in said set is. 
The game ends when the user hits the end game button or all of the cards in the deck are removed. Based on the methods that Quan made, a dialogue message pops up with which player won (or if it was a tie). 
If a player does not know the rules of the game, they can click on a button in the top right corner to open a popup which has the rules written on it. All of this functionality was implemented by Quantez.
All methods in the setWindow class except choosePlayer and replaceCard were created by Quantez. 
The code in the choosePlayer method (in setWindow.rb) was made by Quantez. In the setText file, he fixed an error that had occurred. In the properSet file he took the logic in the is_set method and condensed it down into fewer lines, and fixed a couple errors with it. 
In the same_or_dif method he added the base for the code. In the test file for proper set he changed the cards being created to get the tests to work and changed the assert statements. 
In the main file, he put the method setWindow. 
In the board file, he created the get_card, get_card_index, and find_set methods. In the test file for board, he created tests for get_card, get_card_index, and find_set. He also finished the test for update_board. Those methods and tests he created or assisted with are documented in the files.    

# etc
