=begin
 File created on 9/7 by Gavin A
 Edited 9/12 by Gavin A
 Edited 9/16 by Gavn A
=end
require "test/unit"
require_relative '../deck.rb'

class DeckTest < Test::Unit::TestCase
=begin
     Created 9/7 by Gavin A
     Edited 9/12 by Gavin A: changed test name for accuracy
     Ensues that the length of an initialized deck is 81
=end
    def test_init_length
        deck = Deck.new
        assert_equal 81, deck.length, "deck length should be 81"
    end

=begin
     Created 9/7 by Gavin A
     Ensures a valid card is in the initial, untouched deck
=end
    def test_include_true_1
        deck = Deck.new
        card = Card.new("1", "purple", "tilda", "solid")
        assert deck.include?(card)
    end

=begin
     Created 9/12 by Gavin A
     Ensures a valid card is in the initial, untouched deck
=end
    def test_include_true_2
        deck = Deck.new
        card1 = Card.new("2", "red", "pill", "empty")
        assert deck.include?(card1), "this card should be a member of the deck"
    end

=begin
     Created 9/12 by Gavin A
     Ensures an invalid card is not in the initialized deck
=end
    def test_include_false_1
        deck = Deck.new
        card = Card.new("1", "1", "diamond", "striped")
        assert !deck.include?(card)
    end
    def test_include_false_2
        deck = Deck.new
        card = Card.new("solid", "2", "red", "tilda")
        assert !deck.include?(card)
    end

=begin
     Created 9/7 by Gavin A
     Endures that the remove method in the Deck class removes the card from the deck and decrements its length
=end
    def test_remove_1
        deck = Deck.new
        card = deck.remove
        assert_equal 80, deck.length, "new deck length should be 80"
        assert !deck.include?(card), "deck should not include removed card"
    end

=begin
     Created 9/12 by Gavin A
     Edited 9/16 by Gavin A: Replaced for loop with 10.times and removed assignment statement
     Endures that the remove method in the Deck class decrements the decks length
=end
    def test_remove_2
        deck = Deck.new
        10.times do
            deck.remove
        end
        assert_equal 71, deck.length, "new deck length should be 71"
    end

=begin
     Created 9/16 by Gavin A
     Endures that the remove method in the Deck class decrements the decks length
     Ensures that trying to remove more cards when the deck is empty does not cause an error
=end
    def test_remove_3
        deck = Deck.new
        81.times do
            deck.remove
        end
        assert_equal 0, deck.length, "new deck length should be 0"
        deck.remove
        assert_equal 0, deck.length, "deck length should still be 0"
    end
end