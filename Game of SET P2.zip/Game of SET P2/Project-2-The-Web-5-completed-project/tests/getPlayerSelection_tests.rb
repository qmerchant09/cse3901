=begin
# File created 9/9 by Roberto D
# File edited 9/16 by Roberto D: Added appropriate descriptions
=end
require "test/unit"
require 'stringio'
require_relative '../setText.rb'

class GetPlayerSelectionTest < Test::Unit::TestCase
=begin
    # Created 9/9 by Roberto D
    # test to see if playerSelection will return 1
=end
    def test_playerSelection_1
        io = StringIO.new("1\n")
        $stdin = io
        player = playerSelection
        $stdin = STDIN
        assert_equal player, 1, "player should be 1"
    end
=begin
    # Created 9/9 by Roberto D
    # test to see if playerSelection will return 2
=end
    def test_playerSelection_2
        io = StringIO.new("2\n")
        $stdin = io
        player = playerSelection
        $stdin = STDIN
        assert_equal player, 2, "player should be 2"
    end
=begin
    # Created 9/9 by Roberto D
    # test to see if playerSelection will not accept a smaller invalid input and will ask again for a valid input
=end
    def test_playerSelection_0_2
        io = StringIO.new("0\n2\n")
        $stdin = io
        player = playerSelection
        $stdin = STDIN
        assert_equal player, 2, "player should be 2"
    end
=begin
    # Created 9/9 by Roberto D
    # test to see if playerSelection will not accept a larger invalid input and will ask again for a valid input
=end
    def test_playerSelection_9_1
        io = StringIO.new("9\n1\n")
        $stdin = io
        player = playerSelection
        $stdin = STDIN
        assert_equal player, 1, "player should be 1"
    end
=begin
    # Created 9/9 by Roberto D
    # test to see if playerSelection will not accept an empty input and will ask again for a valid input
=end
    def test_playerSelection_empty_1
        io = StringIO.new("\n\n1")
        $stdin = io
        player = playerSelection
        $stdin = STDIN
        assert_equal player, 1, "player should be 1"
    end
=begin
    # Created 9/16 by Roberto D
    # test to see if playerSelection will not accept repeated invalid inputs and will ask again and accept a valid input
=end
    def test_playerSelection_empty_11_2
        io = StringIO.new("\n\n11\n2")
        $stdin = io
        player = playerSelection
        $stdin = STDIN
        assert_equal player, 2, "player should be 1"
    end
=begin
    # Created 9/16 by Roberto D
    # test to see if playerSelection will not accept repeated invalid inputs and will ask again and accept a valid input
=end
    def test_playerSelection_22_empty_1
        io = StringIO.new("\n22\n\n1")
        $stdin = io
        player = playerSelection
        $stdin = STDIN
        assert_equal player, 1, "player should be 1"
    end
end