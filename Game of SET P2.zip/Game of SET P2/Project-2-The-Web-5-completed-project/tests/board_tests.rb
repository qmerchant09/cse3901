=begin
File created 9/9 by Amyas Dawson
 Edited 9/12 by Gavin A
 Edited 9/16 by Amyas D
=end
require "test/unit"
require_relative '../board.rb'
require_relative '../deck.rb'

class GameBoardTest < Test::Unit::TestCase
=begin
     Created 9/9 by Amyas D 
     Edited 9/12 by Gavin A: Finshed writing the test, changed test name so it runs
     Tests the length method of the Board class for an empty board
=end
    def test_length_1
        board = Board.new
        assert_equal 0, board.length, "board length should be 0"
    end
    
=begin
    Created 9/16 by Amyas D
     Tests the length method and generate_cards method of the Board class
=end
    def test_length_2
        board = Board.new
        deck = Deck.new
        num = 12
        board.generate_cards(deck, num)
        assert_equal 12, board.length, "board length should be 12"
    end
=begin
     Created 9/16 by Amyas D
     Edited 9/19 by Gavin A: Removed parentheses
     Edited 9/22 by Quantez Merchant: Finished code for test
     Tests the remove_three and update_board methods of the Board class
=end
    def test_update_board
        board = Board.new
        deck = Deck.new
        num = 78
        board.generate_cards(deck, num)
        board.remove_three [0,1,2]
        board.update_board deck, [0,1,2]
        assert_equal 75, board.length, "board length should be 75"
        assert_equal 0, deck.length, "deck length should be 0"
     end
=begin
     Created 9/16 by Quantez Merchant
     Edited 9/16 by Amyas D: replaced normal_board with generate_cards along with necessary parameters 
     Tests that the get_card method returns a valid card number
=end
    def test_get_card_1
        board = Board.new
        deck = Deck.new
        num = 12
        board.generate_cards(deck, num)
        assert_include "1".."3", board.get_card(1).number
    end
=begin
       Created 9/19 by Gavin A
       Ensures that the card removed from one deck for a board still exists in an initialized deck
=end
      def test_get_card_2
        board = Board.new
        deck1 = Deck.new
        deck2 = Deck.new
        board.generate_cards(deck1, 1)
        card = board.get_card(0)
        assert !deck1.include?(card), "deck should no longer include the card"
        assert deck2.include?(card), "deck2 should still include the card"
    end
=begin
      Created 9/19 by Gavin A
      Tests the remove_three method of the Board class with indicies satisfying the requires clause
=end
     def test_remove_three_1
        deck = Deck.new
        board = Board.new
        board.generate_cards(deck, 12)
        board.remove_three([2, 4, 5])
        assert_equal 9, board.length, "board length should be 9 after removing 3"
    end

=begin
      Created 9/19 by Gavin A
      Tests the remove_three method of the Board class with indicies satisfying the requires clause
=end
    def test_remove_three_2
        deck = Deck.new
        board = Board.new
        board.generate_cards(deck, 3)
        board.remove_three([0, 1, 2])
        assert_equal 0, board.length, "board length should be 0 after removing 3"
    end
=begin
      Created 9/19 by Gavin A
      Tests the remove_three method of the Board class with indicies satisfying the requires clause
=end
    def test_remove_three_3
        deck = Deck.new
        board = Board.new
        board.generate_cards(deck, 15)
        board.remove_three([0, 1, 14])
        assert_equal 12, board.length, "board length should be 12 after removing 3"
    end

=begin
     Created 9/22 by Quantez Merchant
     Tests the get_card_index of the Board class asserting that the index of the given card matches 
=end
    def test_get_card_index_1
        board = Board.new
        deck = Deck.new
        num = 81
        board.generate_cards(deck, num)
        card = board.get_card(5)
        assert_equal 5, board.get_card_index(card) 
    end

      # Created 9/22 by Quantez Merchant
      def test_get_card_index_2
        board = Board.new
        deck = Deck.new
        num = 81
        board.generate_cards(deck, num)
        card = board.get_card(82)
        assert_equal nil, board.get_card_index(card) 
    end
=begin
     Created 9/22 by Quantez Merchant
     Edited 9/22 by Gavin A: Makes sure a set always exists by including all the cards in the deck
     Ensures that find_set method works by checking if the entire deck has a set (which it always will)
=end
    def test_find_set_1
        board = Board.new
        deck = Deck.new
        num = 81
        board.generate_cards(deck, num)
        set = board.find_set
        assert_include 0..80, board.get_card_index(set[0]) 
        assert_include 0..80, board.get_card_index(set[1]) 
        assert_include 0..80, board.get_card_index(set[2]) 
    end
=begin
     Created 9/22 by Quantez Merchant
     Ensures that a board with no cards does not return a false positive for the find_set method
=end
    def test_find_set_2
        board = Board.new
        deck = Deck.new
        num = 0
        board.generate_cards(deck, num)
        set = board.find_set
        assert_equal nil, set
    end
end      
        
