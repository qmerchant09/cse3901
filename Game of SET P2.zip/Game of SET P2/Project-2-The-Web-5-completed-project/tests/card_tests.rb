=begin 
File created on 9/7 by Gavin A
Edited 9/8 by Gavin A
Edited 9/12 by Gavin A
Edited 9/22 by Gavin A: Deleted parentheses, removed tests for the unused method, added description for tests
=end
require "test/unit"
require_relative '../card.rb'

class CardTest < Test::Unit::TestCase
=begin
    # Created 9/7 by Gavin A
    # Tests if the attr_reader method for each attribute returns the correct value
=end
    def test_number
        numbers = ["1", "2", "3"]
        numbers.each do |number|
            card = Card.new number, "null", "null", "null"
            assert_equal number, card.number, "card.number should return #{number} but was #{card.number}"
        end
    end
    def test_color
        colors = [:purple, :red, :green]
        colors.each do |color|
            card = Card.new "null", color, "null", "null"
            assert_equal color, card.color, "card.color should return #{color} but was #{card.color}"
        end
    end
    def test_shape
        shapes = [:diamond, :pill, :tilda]
        shapes.each do |shape|
            card = Card.new "null", "null", shape, "null"
            assert_equal shape, card.shape, "card.shape should return #{shape} but was #{card.shape}"
        end
    end
    def test_shading
        shadings = [:empty, :solid, :striped]
        shadings.each do |shading|
            card = Card.new "null", "null", "null", shading
            assert_equal shading, card.shading, "card.shading should return #{shading} but was #{card.shading}"
        end
    end

=begin
    # Created 9/7 by Gavin A
    # Tests if the equal_to method correctly determines card equality
=end
    def test_equal_to_true
        card1 = Card.new("2", "purple", "diamond", "striped")
        card2 = Card.new("2", "purple", "diamond", "striped")
        assert card1.equal_to?(card2), "These two cards should be the same"
    end
    def test_equal_to_false_1
        card1 = Card.new("3", "purple", "diamond", "striped")
        card2 = Card.new("2", "purple", "diamond", "striped")
        assert !card1.equal_to?(card2), "These two cards are not the same"
    end
    def test_equal_to_false_2
        card1 = Card.new("3", "red", "diamond", "striped")
        card2 = Card.new("2", "purple", "tilda", "empty")
        assert !card1.equal_to?(card2), "These two cards are not the same"
    end
=begin
    # Created 9/8 by Gavin A
    # Edited 9/12 by Gavin A: Now asserts instead of printing the filename
    # Tests the return value of the filename mathod in the Card class
=end
    def test_filename_1
        card = Card.new "3", "red", "diamond", "striped"
        assert_equal card.filename, "3rdst"
    end
    def test_filename_2
        card = Card.new "1", "purple", "pill", "solid"
        assert_equal card.filename, "1ppso"
    end
    def test_filename_3
        card = Card.new "2", "green", "tilda", "empty"
        assert_equal card.filename, "2gtem"
    end
end