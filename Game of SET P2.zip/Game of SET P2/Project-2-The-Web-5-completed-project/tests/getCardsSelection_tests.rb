=begin
# File created 9/9 by Roberto D
# Edited 9/16 by Roberto D
=end
require "test/unit"
require 'stringio'
require_relative '../setText.rb'

class GetCardsSelectionTest < Test::Unit::TestCase
=begin
    # Created 9/9 by Roberto D
    # test cardsSelection to see if an appropriate set gets saved correctly
=end
    def test_cardsSelection_1_2_3
        io = StringIO.new("1 2 3\n")
        $stdin = io
        cardIndexes = cardsSelection 1, 12
        $stdin = STDIN
        assert_equal cardIndexes, ["1", "2", "3"], "cardIndexes should be ['1', '2', '3']"
    end
=begin
    # Created 9/9 by Roberto D
    # test cardsSelection to see if an input with less than 3 indexes is not saved
=end
    def test_cardsSelection_1
        io = StringIO.new("1\n")
        $stdin = io
        cardIndexes = cardsSelection 2, 12
        $stdin = STDIN
        assert_nil cardIndexes, "cardIndexes should nil"
    end
=begin
    # Created 9/9 by Roberto D
    # test cardsSelection to see if an input with an index that is smaller than the 1-12 range is not saved
=end
    def test_cardsSelection_0_9_2
        io = StringIO.new("0 9 2\n")
        $stdin = io
        cardIndexes = cardsSelection 1, 12
        $stdin = STDIN
        assert_nil cardIndexes, "cardIndexes should nil"
    end
=begin
    # Created 9/9 by Roberto D
    # test cardsSelection to see if an input with an index that is larger than the 1-12 range is not saved
=end
    def test_cardsSelection_4_7_13
        io = StringIO.new("4 7 13\n")
        $stdin = io
        cardIndexes = cardsSelection 1, 12
        $stdin = STDIN
        assert_nil cardIndexes, "cardIndexes should nil"
    end
=begin
    # Created 9/9 by Roberto D
    # test cardsSelection to see if an input with a duplicate index is not saved
=end
    def test_cardsSelection_1_1_4
        io = StringIO.new("1 1 4\n")
        $stdin = io
        cardIndexes = cardsSelection 2, 12
        $stdin = STDIN
        assert_nil cardIndexes, "cardIndexes should nil"
    end
=begin
    # Created 9/9 by Roberto D
    # test cardsSelection to see if an input with more than 3 indexes is not saved
=end
    def test_cardsSelection_empty
        io = StringIO.new("1 2 3 4\n")
        $stdin = io
        cardIndexes = cardsSelection 1, 12
        $stdin = STDIN
        assert_nil cardIndexes, "cardIndexes should nil"
    end
=begin
    # Created 9/16 by Roberto D
    # test getInput to see if no input will time out the player and proceed
=end
    def test_getInput_no_input
        puts "DO NOT ENTER AN INPUT. WAIT 10 SECONDS."
        playerInput = getInput 1
        assert_nil playerInput, "playerInput should be nil"
    end
end