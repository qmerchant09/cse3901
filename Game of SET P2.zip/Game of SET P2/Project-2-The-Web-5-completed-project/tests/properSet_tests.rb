=begin
  File created on 9/8 by selemon1
  Edited 9/11/22 by selemon1
  Edited 9/12 by Gavin A
  Edited 9/14 by Gavin A
  Edited 9/14/22 by selemon1
  Edited 9/15/22 by selemon1
  Edited 9/16 by Gavin A
  Edited 9/22 by Gavin A: Added '?' to the end of method calls to relect change in properSet file
=end
 require "test/unit"
 require_relative '../properSet.rb'
 require_relative '../card.rb'
 
 class ProperSetTests < Test::Unit::TestCase
=begin
      Created 9/8 by selemon1
      Edited 9/11/22 by selemon1 
     Edited by selemon1 9/14: correcting the method name and 
        correcting error by creating 3 cards 
      Edited by Selemon1 9/15/22
      Edited by Quantez Merchant 9/15/22
      Edited by Selemon1 9/16/22:Edited Cards, documentation and corrected errors
      Edited by Quantez Merchant 9/16/22
      Edited 9/22 by Selemon1: Fixed syntax error by removing ! and replace with ?
 ensure three cards that should make a set return true from is_set?
=end
     def test_is_set_true_1  
         card1 = Card.new("red", "2", "pill", "solid")
         card2 = Card.new("red","2", "pill", "striped")
         card3 = Card.new("red","2", "pill", "empty")
         assert is_set?(card1,card2,card3)
     end
=begin
      Created 9/8 by selemon1
      Edited 9/11/22 by selemon1
     Edited by selemon1 9/14: correcting the method name and correcting error
      Edited by Selemon1 9/15/22
      Edited by Quantez Merchant 9/15/22
      Edited by Selemon1 9/16/22:Edited Cards and corrected errors
      Edited by Quantez Merchant 9/16/22
      Edited 9/22 by Selemon1: Fixed syntax error by adding "?"
     A second test case when the set is set
=end
     def test_is_set_true_2
         card1 = Card.new("red", "1", "tilda", "solid")
         card2 = Card.new("green","2", "diamond", "solid")
         card3 = Card.new("purple","3", "pill", "solid")
         assert is_set?(card1,card2,card3)
     end
=begin
     created 9/11 by selemon1
     Edited by selemon1 9/14: correcting the method name 
      Edited by Quantez Merchant 9/15/22
      Edited by Selemon1 9/15/22
      Edited by Selemon1 9/16/22:Edited Cards and corrected errors
      Edited by Quantez Merchant 9/16/22
      Edited 9/22 by Selemon1: Fixed syntax error by adding "?"
     A third test case when the set is set
=end
      def test_is_set_true_3
         card1 = Card.new("red", "1", "tilda", "striped")
         card2 = Card.new("green","2", "diamond", "empty")
         card3 = Card.new("purple","3", "pill", "solid")
         assert is_set?(card1,card2,card3)
     end
=begin
      Created 9/8 by selemon1
      Edited 9/11/22 by selemon1
     Edited by selemon1 9/14: correcting the method name 
      Edited by Selemon1 9/15/22
      Edited by Quantez Merchant 9/15/22
      Edited by Selemon1 9/16/22:Edited Cards and corrected errors
       Edited 9/22 by Selemon1: Fixed syntax error by adding "?"
     A test when the set is not set
=end
     def test_is_set_false_1
         card1 = Card.new("red", "1", "diamond", "solid")
         card2 = Card.new("green","1", "diamond", "empty")
         card3 = Card.new("purple","1", "diamond", "empty")
         assert !is_set?(card1,card2,card3)
     end
=begin
      Created 9/8 by selemon1
      Edited 9/11/22 by selemon1
     Edited by selemon1 9/14: correcting the method name
       Edited by Selemon1 9/15/22
      Edited by Quantez Merchant 9/15/22
      Edited by Selemon1 9/16/22:Edited Cards and corrected errors
       Edited 9/22 by Selemon1: Fixed syntax error by adding "?"
     a second test when the set is not set
=end
     def test_is_set_false_2
         card1 = Card.new("purple", "3", "pill", "solid")
         card2 = Card.new("red","1", "diamond", "solid")
         card3 = Card.new("purple","2", "pill", "empty")
         assert !is_set?(card1,card2,card3)
     end
=begin
      Created 9/11 by selemon1
     edited 9/11/22 by selemon1
     Edited by selemon1 9/14: correcting the method name and correted error
      Edited by Selemon1 9/15/22
      Edited by Quantez Merchant 9/15/22
      Edited by Selemon1 9/16/22:Edited Cards and corrected errors
       Edited 9/22 by Selemon1: Fixed syntax error by adding "?"
     A third test when the set is not set
=end
     def test_is_set_false_3
         card1 = Card.new("red", "2", "tilda", "solid")
         card2 = Card.new("red","2", "tilda", "striped")
         card3 = Card.new("green","2", "tilda", "empty")
         assert_equal false, is_set?(card1,card2,card3)
     end
=begin
      Created 9/12 by Gavin A
      Edited 9/14 by Gavin A: Fixed syntax error by removing "ProperSet."
      Edited 9/22 by Selemon1: Fixed syntax error by adding "?"
      Ensures three different values put into same_or_dif returns true
=end
     def test_same_or_dif_1
         assert same_or_dif?("1", "2", "3")
     end
=begin
      Created 9/12 by Gavin A
      Edited 9/14 by Gavin A: Fixed syntax error by removing "ProperSet."
      Ensures that only two identical values in the 1st and 2nd params returns false
=end
     def test_same_or_dif_2
        assert !same_or_dif?("2", "2", "3")
     end
=begin
      Created 9/12 by Gavin A
      Edited 9/14 by Gavin A: Fixed syntax error by removing "ProperSet."
      Ensures three identical values put into same_or_dif returns true
=end
     def test_same_or_dif_3
        assert same_or_dif?("diamond", "diamond", "diamond")
     end
=begin
      Created 9/12 by Gavin A
      Edited 9/14 by Gavin A: Fixed syntax error by removing "ProperSet."
      Ensures three different values put into same_or_dif returns true
=end
     def test_same_or_dif_4
         assert same_or_dif?("tilda", "diamond", "pill")
     end

=begin
      Created 9/16 by Gavin A
      Ensures that only two identical values in the 1st & 3rd params returns false
=end
     def test_same_or_dif_5
        assert !same_or_dif?("solid", "striped", "solid")
     end
=begin
      Created 9/16 by Gavin A
      Ensures that only two identical values in the 2nd and 3rd params returns false
=end
     def test_same_or_dif_6
        assert !same_or_dif?("solid", "pill", "pill")
     end
 end
 