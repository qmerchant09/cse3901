=begin
File Created on 9/19 by Gavin A
Edited 9/21 by Amyas D
Edited 9/22 by Gavin A: Moved ard and player selection methods to this file
=end
require_relative './deck.rb'
require_relative './board.rb'
require_relative './card.rb'
require_relative './PlayersScore.rb'

=begin 
    Created 9/19 by Gavin A
    Edited 9/21 by Amyas D: Checked if proper set is made. If so, player score is 
        increased and printed to console. Old cards on the board are replaced with new ones. 
        Added player score and reduced lines of code
    Edited 9/22 by Gavin A: Fixed error where the index was out of bounds for 12
    Edited 9/22 by Quantez Merchant: Fixed argument error on line 28
        Changed while loop to be when the board length is empty
        The game adds three cards to the board if a set can't be found
    Edited 9/22 by Gavin A: Now removes the cards that made a set if the deck is empty or not
    Edited 9/22 by Roberto D: Now checks if cardsSelection returns nil
    This is the method for running the text-based game of set
=end

def setText
    deck = Deck.new
    board = Board.new
    board.generate_cards deck, 12
    playerScores = PlayerScores.new
    while board.length > 0 do
        if board.find_set == nil then 
            board.generate_cards deck,3 
        end
        board.print_board
        puts "When you think you've found a set, enter which player you are"
        player = playerSelection
        cardSelection = cardsSelection player, board.length
        if (cardSelection != nil) 
            madeSet= is_set? board.get_card(cardSelection[0].to_i - 1),board.get_card(cardSelection[1].to_i - 1),board.get_card(cardSelection[2].to_i - 1)
            playerScores.player_scores player,madeSet
            if madeSet
                (deck.length == 0 || board.length >12) ? (board.remove_three cardSelection) : (board.update_board deck, cardSelection)
            end
        end
    end
    playerScores.winner deck
end

=begin
Created 9/7 by Roberto D
Edited 9/8 by Roberto D: Added loop to ensure correct input
playerSelection runs until the user enters a '1' or '2' to select which player will make a set selection and returns the '1' or '2'
=end
def playerSelection
    player = 0
    until player == 1 or player == 2
        puts "Player 1 enter '1' to make a selection. Player 2 enter '2' to make a selection."
        player = gets.chomp.to_i
    end
    player
end


=begin 
    Created 9/7 by Roberto D
    Edited 9/8 by Roberto D: Added array to store card indexes
    Edited 9/9 by Roberto D: Added loop to check if each index input by the user is valid. Improved variable names.
    Edited 9/13 by Roberto D: Added timer method to give time limit for player to select cards
    Edited 9/14 by Roberto D: Removed for loop for array.each
    Edited 9/16 by Roberto D: Removed debug code
    Edited 9/19 by Gavin A; Added the board length as a parameter, removed parentheses

    cardsSelection calls getInput to receive a String that the player inputs. 
    cardsSelection then makes this string an array with the split method.
    This array is tested to see if the input meets the following criteria:
    1) It has 3 indexes
    2) Each index is different (no duplicates)
    3) Each index is between 1 and length
    If all three criteria are met, it returns the array of indexes, otherwise, it returns nil.
=end
def cardsSelection player, boardLength
    playerInput = getInput player

    if playerInput != nil
        cardIndexes = playerInput.split (/ /)
        if cardIndexes.length != 3 || cardIndexes.uniq.length != 3
            puts "Error: Choose 3 different cards"
            cardIndexes = nil
        else  
            cardIndexes.each do |index| 
                if index.to_i < 1 or index.to_i > boardLength
                    puts "Error: Invalid card index."
                    cardIndexes = nil
                end
            end
        end
        cardIndexes
    end
end

=begin
    Created 9/13 by Roberto D
    Edited 9/14 by Roberto D to remove unnecessary value assignment
    Edited 9/16 by Roberto D: Renamed method to more accurate description of the function.
    
    getInput uses two Threads. It uses a playerInput Thread to get input, and a timer Thread to count down
       10 seconds for the player to enter their input. The playerInput Thread will kill the timer Thread
       when an input is received. If no input is received, it will print "Time's up" and move on.
       The input is returned if an input is received, and nil is returned if no input is received.
=end
def getInput player
    playerInput = Thread.new do
        puts "Player #{player} choose your set by typing the indeces of the cards separated by a space (ex: 4 7 12)"
        Thread.current[:input] = gets.chomp
    end

    timer = Thread.new {sleep 10; playerInput.kill}
    playerInput.join

    if !playerInput[:input]
        puts "Time's up!"
    end

    playerInput[:input]
end