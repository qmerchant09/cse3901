=begin
File created on 9/5 by Gavin A
File edited on 9/7 by Gavin A
File edited on 9/9 by Gavin A
Edited 9/16 by Gavin A
Edited 9/21 by Gavin A

This class is the representation for a card in the Game of Set
Each instance of the card class will have 4 attributes: color, shape, shading, and number
This class has methods for retrieving each attribute and generating a filename for the card instance based on it's attributes
=end
class Card
    attr_reader :number, :color, :shape, :shading
=begin
     Created 9/5 by Gavin A
     Edited 9/7 by Gavin A: Switched to using parallel assignment
     Edited 9/16 by Gavin A: Removed parentheses
     Constructs a representation of a card with 4 values passed into the parameters
=end
    def initialize number, color, shape, shading
        @number, @color, @shape, @shading = number, color, shape, shading
    end

    # Created 9/7 by Gavin A
    # Determines if the instance of card passed as a parameter is equal to the current card instance
    def equal_to? card
        @number == card.number && @color == card.color && @shape == card.shape && @shading == card.shading
    end

=begin
     Created 9/8 by Gavin A
     Returns a unique filename for the card instance
     Requires that the card instance and each of its attributes are not nil
     For example, a card with three empty purple diamonds will have a filename of "3pdem"
=end
    def filename
        @number[0] + @color[0] + @shape[0] + @shading[0,2] 
    end
end