=begin
File Created by Selemon1 9/18/2022
 Edited by Selemon1 9/18/2022
 Edited 9/20/22 by selemon1
 Edited 9/21/22 by selemon1
 Edited 9/22 by Gavin A
 Edited 9/22 by Roberto D
=end
require_relative './deck.rb'

=begin
 Edited 9/19/2022 by selemon1: adding more logic 
 Edited 9/19/2022 by selemon1: correcting syntax error and change the order
       of the statments
 Created by Selemon1 9/18/2022
 Edited 9/21/2022 by selemon1: correcting logical errors
 This class is the representation of the scores of the two players for the Game of Set
 The class allows a caller to increase a player's score or determine a winner for the end of the game
=end
class PlayerScores

=begin
Created 9/21 by Amyas D
The player scores will be represented by an array, where scores[0] = player1 and scores[1] = player2
=end
def initialize
    @scores = [0,0]
end
=begin
 Created by Selemon1 9/18/2022, a method that increse the score 
       when the selected cards make a proper set
Edited 9/21 by Amyas D: added parameters, added messages to console, refactored code, and added function comment
 Edited 9/22 by Roberto D: Minor grammatical fix

   Updates the player scores if they select a proper set and prints a corresponding message.
   Parameters:  Needs the current player @player Needs a boolean @madeSet that determines if a proper set was made
=end
def player_scores player, madeSet
    if !madeSet
        puts "It is not a set. Try again." 
    else   
        puts"You made a set!"
        @scores[player-1] += 1 
        puts "Player 1 Score: " + playerScores[0] + "\nPlayer 2 Score: " + playerScores[1]    
    end
end
=begin
 Created 9/20/22 by Selemon1
 Edited 9/21/22 by selemon1, renaming the method and fix errors 
 Edited 9/21/2022 by selemon1: correcting logical errors
Edited 9/21 by Amyas D: update function name, added parameter
 Setting a winning condition for the game when the deck parameter @deck is empty 
 Edited 9/22 by Selemon1: Fixed syntax error by removing the deck paramter 
       because we already check the deck length in the setText and removed the extra end
 Edited 9/22 by Roberto D: Minor grammatical fix
 Prints a game over message and determines who won based on player scores
=end
def winner 
    if @scores[0] > @scores[1]
        puts "The game is over.\nPlayer 1 wins!"
    elsif @scores[1] > @scores[0]
        puts "The game is over.\nPlayer 2 wins!"
    else
        puts "The game is over.\nTie Game."
    end
end
end
