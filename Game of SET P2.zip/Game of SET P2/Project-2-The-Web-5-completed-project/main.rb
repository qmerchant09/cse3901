=begin
File created 9/12 by Gavin A
 Edited 9/16 by Gavin A
 Edited 9/19 by Gavin A
 Edited 9/21 by Gavin A
 Edited 9/21 by Roberto D: Removed debug code
 Edited 9/22 by Gavin A
=end
require_relative './setWindow.rb'
require_relative './setText.rb'

=begin
 Created 9/19 by Gavin A
 Edited 9/20 by Gavin A: Put the game version selection into its own method
 Edited 9/22 by Quantez Merchant: replaced the setwindow code with the setWindow method
 The main method starts up the game and asks users to choose whether to play the game
 using a mouse-based grahical front-end or a text-based version using the console
=end
def main
    puts "Welcome to the Game of Set!\nPlease select how you'd like to play."
    option = gameVersion
    if option == 2
       setWindow
    else
        setText
    end
end

=begin
 Created 9/21 by Gavin A
 gameVersion runs until the user enters a '1' or '2' to select which version of the game to play and returns the '1' or '2'
=end
def gameVersion
    option = 0
    until option == 1 or option == 2
        puts "Enter 1 for text based\nEnter 2 for mouse based"
        option = gets.chomp.to_i
    end
    option
end

main
