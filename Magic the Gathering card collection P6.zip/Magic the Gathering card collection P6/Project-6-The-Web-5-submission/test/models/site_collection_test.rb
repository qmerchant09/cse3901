require "test_helper"

class SiteCollectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
