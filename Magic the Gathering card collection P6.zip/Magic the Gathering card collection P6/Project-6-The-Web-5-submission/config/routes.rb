# Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

Rails.application.routes.draw do
  # Written 11/28 by Gavin A
  # Edited 11/28 by quantez merchant: added put routes for collection
  # Edited 11/29 by Roberto D: added routes for remove and collection_value
  #Edited 11/29 by Amyas D: added get route for site_collection/index and post for collection/add_to_collection

  get 'cards/index'
  get 'cards/show'
  get 'cards/create'
  get 'cards/edit'
  delete 'cards/remove'
  get 'users/index'
  get 'users/show'
  get 'users/create'
  get 'users/destroy'
  get 'collection/index'
  get 'collection/collection_value'
  put 'collection/filter_rarity'
  put 'collection/filter_name'
  post 'collection/add_to_collection'
  get 'site_collection/index'

  # Written 11/28 by Gavin A
  devise_for :users
  
  # Defines the root path route ("/")  
  root "cards#index"
  
  # Defines the path route ("index") to the root
  get '/index', to: 'cards#index'
  
  # Defines the path route to an individual card page
  get "/cards/:id", to: "cards#show"
  resources :users
end
