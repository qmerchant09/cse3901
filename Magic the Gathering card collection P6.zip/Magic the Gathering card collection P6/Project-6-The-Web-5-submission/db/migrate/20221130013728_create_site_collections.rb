class CreateSiteCollections < ActiveRecord::Migration[7.0]
  def change
    create_table :site_collections do |t|
      t.string :name
      t.string :printing
      t.string :rarity
      t.string :type
      t.string :color
      t.text :description
      t.integer :quantity
      t.float :price

      t.timestamps
    end
  end

  class SiteCollections < ActiveRecord::Base
    attr_accessor :name, :printing, :rarity, :type, :color, :description, :quantity, :price
  end
end