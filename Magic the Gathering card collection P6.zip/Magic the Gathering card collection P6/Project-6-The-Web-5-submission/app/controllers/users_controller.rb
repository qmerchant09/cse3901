=begin
  File created 11/25 by Gavin A
  File edited 11/28 by Gavin A: Removed methods already defined by Devise
=end
class UsersController < ApplicationController
  before_action :authenticate_user!, except: [:show]
   
  #Created by Gavin A
  def show
    @user = User.find(params[:id])
    #todo: restrict only to card collections of @user
    @collections = Collection.all
  end

  # Created by Gavin A
  def destroy
    redirect_to root_path, status: :see_other
  end
end
