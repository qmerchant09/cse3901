=begin
  File created 11/28 by Gavin A
  File edited 11/29 by Roberto D: added remove method
=end
class CardsController < ApplicationController
  #Require the user be logged in with devise to complete any actions except for index and show
  before_action :authenticate_user!, except: [:index, :show]

=begin
  Created 11/28 by Gavin A
  GET /cards: Get an array of all cards in the system
=end
  def index
    @cards = Card.all
    @users = User.all
  end

=begin
  Created 11/28 by Gavin A
  GET /cards/id: Gets a card with a specific id 
=end
  def show
    @card = Card.find(params[:id])
  end

=begin
  Created 11/28 by Gavin A
  POST /cards: Creates a new card in the cards database
=end
  def create
    @card = current_user.collections.build(card_params)

    if @card.save
      redirect_to @card
    else
      render :new, status: :unprocessable_entity
    end
  end

=begin
  Created 11/28 by Gavin A
  PUT /cards/id: Edits a card
=end
  def edit
  end

=begin
  Created 11/29 by Roberto D
  DELETE /cards/id: Removes a card from card database
=end
def remove
  @card.destroy
end  

  private
    #Only allow params that we already have set up
    def card_params
      params.require(:card).permit(:name, :printing, :rarity, :type, :color, :description, :quantity)
    end
end
