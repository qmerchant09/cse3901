#File created by quantez merchant 11/28
#File edited by Roberto D 11/29: Added method to get the value of collection
class CollectionController < ApplicationController
   #Require the user be logged in with devise to complete any actions except for index and show
   before_action :authenticate_user!, except: [:index]
  def index
    @collection = Collection.all
  end

  def filter_rarity
  end

  def filter_name
  end

  def collection_value cards
    sum = 0
    cards.each {|card| sum = sum + card.price}
    sum
  end

  def add_to_collection card
  end
end
