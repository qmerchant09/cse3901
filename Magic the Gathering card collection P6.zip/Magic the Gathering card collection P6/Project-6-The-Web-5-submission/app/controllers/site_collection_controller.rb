class SiteCollectionController < ApplicationController
  def index
  end
end
