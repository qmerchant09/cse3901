# Created by Gavin A
class Card < ApplicationRecord
  has_many :collections, dependent: :destroy
  validates :name, presence: true
  validates :printing, presence: true
  validates :rarity, presence: true
  validates :type, presence: true
  validates :color, presence: true
  validates :quantity, presence: true
end
