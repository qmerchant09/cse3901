class SiteCollection < ApplicationRecord
end
